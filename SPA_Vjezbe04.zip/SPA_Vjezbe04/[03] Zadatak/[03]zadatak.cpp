#include<iostream>
#include<ctime>
#include"Z03_Studenti.h"
using namespace std;

int main() {

	srand(time(nullptr));
	Z03_Studenti PoljeStudenata[3];

	for (int i = 0; i < 3; i++) {
		string t;
		cout << "Upisite ime " << i + 1 << ". studenta: ";
		getline(cin, t);
		PoljeStudenata[i].SetIme(t);

		cout << "Upisite prezime " << i + 1 << ". studenta: ";
		getline(cin, t);
		PoljeStudenata[i].SetPrezime(t);
	}

	cout << "Upisani su sljedeci studenti:" << endl;
	for (int i = 0; i < 3; i++) {
		cout << PoljeStudenata[i].GetImePrezime() << ", " << PoljeStudenata[i].GetGodinaRodjenja() << endl;
	}

	return 0;
}