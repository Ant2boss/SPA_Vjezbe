#include "Z03_Studenti.h"
#include<ctime>

int Z03_Studenti::RandBetween(int min, int max) {
	return std::rand() % (max - min + 1) + min;
}

Z03_Studenti::Z03_Studenti() {
	this->GodinaRodjenja = this->RandBetween(1961, 1997);
}

void Z03_Studenti::SetIme(std::string Ime) {
	this->Ime = Ime;
}

void Z03_Studenti::SetPrezime(std::string Prezime) {
	this->Prezime = Prezime;
}

void Z03_Studenti::SetImePrezime(std::string Ime, std::string Prezime) {
	this->SetIme(Ime);
	this->SetPrezime(Prezime);
}

std::string Z03_Studenti::GetIme() {
	return this->Ime;
}

std::string Z03_Studenti::GetPrezime() {
	return this->Prezime;
}

std::string Z03_Studenti::GetImePrezime()
{
	return std::string(this->GetIme()) + " " + std::string(this->GetPrezime());
}

int Z03_Studenti::GetGodinaRodjenja() {
	return this->GodinaRodjenja;
}
