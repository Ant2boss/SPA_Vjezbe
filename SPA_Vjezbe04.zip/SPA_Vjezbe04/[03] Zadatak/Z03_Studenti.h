#pragma once
#include<string>

class Z03_Studenti {
	std::string Ime;
	std::string Prezime;
	int GodinaRodjenja;

	int RandBetween(int min, int max);

public:
	Z03_Studenti();

	void SetIme(std::string Ime);
	void SetPrezime(std::string Prezime);
	void SetImePrezime(std::string Ime, std::string Prezime);

	std::string GetIme();
	std::string GetPrezime();
	std::string GetImePrezime();
	int GetGodinaRodjenja();
};