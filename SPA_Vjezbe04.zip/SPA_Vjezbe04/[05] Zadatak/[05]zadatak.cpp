#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
using namespace std;

int main() {

	ifstream inDat("Broj_znanstvenika_na_milijun_stanovnika.csv");

	if (!inDat) { 
		cout << "Greska!" << endl;
		return 1; 
	}

	string line;
	getline(inDat, line);
	while (getline(inDat, line)) {

		stringstream ss(line);
		string Naziv;
		getline(ss,Naziv,';');
		
		bool NemaPodataka = true;
		string temp;
		for (int i = 0; i < 10; i++) {
			getline(ss, temp, ';');
			stringstream Pretvarac(temp);
			int broj;
			if (Pretvarac >> broj) {
				NemaPodataka = false;
				break;
			}
		}

		if (NemaPodataka) {
			cout << "Naziv: " << Naziv << endl;
		}
	}

	inDat.close();
	return 0;
}