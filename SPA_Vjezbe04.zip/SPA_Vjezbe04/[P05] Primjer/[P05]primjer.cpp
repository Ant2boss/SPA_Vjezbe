#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
using namespace std;

int main() {

	ifstream InFile("Broj_znanstvenika_na_milijun_stanovnika.csv");
	int BrojZnanstvenika;

	if (!InFile) {
		cout << "Nije moguce pronaci datoteku!" << endl;
		return 404;
	}

	string Redak;
	getline(InFile, Redak);
	while (getline(InFile, Redak)) {
		
		stringstream ssRedak(Redak);
		string NazivDrzave;
		getline(ssRedak, NazivDrzave, ';');
		if (NazivDrzave == "Albania") {
			string Vrijednost;
			for (int i = 0; i < 4; i++) {
				getline(ssRedak,Vrijednost,';');
			}
			stringstream ssPretvornik(Vrijednost);
			ssPretvornik >> BrojZnanstvenika;
			break;
		}
	}

	InFile.close();

	cout << "U albaniji ima na milijun stanovnika " << BrojZnanstvenika << " znanstvenika!" << endl;

	return 0;
}