#pragma once
#include<string>

class Z06_BrojZnanstvenika {
	std::string NazivDrzave;
	int BrojZnanstvenika[10];

public:
	Z06_BrojZnanstvenika();

	void UcitajIzRedka(std::string Redak);
	
	void SetNazivDrzave(std::string NazivDrzave);
	void SetBrojZnanstvenika(int kolicina, int indexGodine);

	std::string GetNazivDrzave();
	int GetBrojZnanstvenika(int indexGodine);
	double GetProsjecniBrojZnanstvenika();
};

