#include<iostream>
#include<fstream>
#include<vector>
#include"Z06_BrojZnanstvenika.h"
using namespace std;

int main() {

	ifstream IFile("Broj_znanstvenika_na_milijun_stanovnika.csv");

	if (!IFile) {
		cout << "Greska prilikom otvranja!" << endl;
		return -1;
	}

	string Redak;
	getline(IFile, Redak);
	vector<Z06_BrojZnanstvenika> PoljeZnanstvenika;
	while (getline(IFile, Redak)) {
		Z06_BrojZnanstvenika temp;
		temp.UcitajIzRedka(Redak);

		PoljeZnanstvenika.push_back(temp);
	}

	cout << "U datoteci se nalaza sljedeci podatci vezani uz broj znanstvenika: " << endl;
	for (int i = 0; i < PoljeZnanstvenika.size(); i++) {
		cout << PoljeZnanstvenika[i].GetNazivDrzave() << ": " << PoljeZnanstvenika[i].GetProsjecniBrojZnanstvenika() << endl;
	}

	IFile.close();
	return 0;
}