#include "Z06_BrojZnanstvenika.h"
#include<sstream>

Z06_BrojZnanstvenika::Z06_BrojZnanstvenika() {
	for (int i = 0; i < 10; i++) this->BrojZnanstvenika[i] = 0;
}

void Z06_BrojZnanstvenika::UcitajIzRedka(std::string Redak) {
	std::stringstream ssRedak(Redak);
	getline(ssRedak, this->NazivDrzave, ';');
	for (int i = 0; i < 10; i++) {
		std::string Vrijednost;
		
		getline(ssRedak, Vrijednost, ';');
		std::stringstream Pretvortnik(Vrijednost);

		int temp;
		if (Pretvortnik >> temp) {
			this->SetBrojZnanstvenika(temp, i);
		}

	}
}

void Z06_BrojZnanstvenika::SetNazivDrzave(std::string NazivDrzave) {
	this->NazivDrzave = NazivDrzave;
}

void Z06_BrojZnanstvenika::SetBrojZnanstvenika(int kolicina, int indexGodine) {
	this->BrojZnanstvenika[indexGodine] = kolicina;
}

std::string Z06_BrojZnanstvenika::GetNazivDrzave() {
	return this->NazivDrzave;
}

int Z06_BrojZnanstvenika::GetBrojZnanstvenika(int indexGodine) {
	return this->BrojZnanstvenika[indexGodine];
}

double Z06_BrojZnanstvenika::GetProsjecniBrojZnanstvenika() {
	int total = 0;
	int count = 0;
	for (int i = 0; i < 10; i++) {
		if (this->BrojZnanstvenika[i] != 0) {
			total += this->BrojZnanstvenika[i];
			count++;
		}
	}
	if (count == 0) return 0;
	return (double)(total / count);
}
