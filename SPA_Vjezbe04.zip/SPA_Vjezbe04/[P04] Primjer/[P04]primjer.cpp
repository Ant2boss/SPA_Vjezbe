#include<iostream>
#include<chrono>
using namespace std;

int main() {

	auto Pocetak = chrono::high_resolution_clock::now();

	for (int i = 1; i <= 100; i++) {
		for (int j = 1; j <= 100; j++) {
			cout << i << " * " << j << " = " << i * j << endl;
		}
	}

	auto Kraj = chrono::high_resolution_clock::now();

	auto Trajanje = chrono::duration_cast<chrono::milliseconds> (Kraj - Pocetak).count();
	cout << "Ispisivanje tablice mnozenja je trajalo: " << Trajanje << "ms" << endl;

	return 0;
}