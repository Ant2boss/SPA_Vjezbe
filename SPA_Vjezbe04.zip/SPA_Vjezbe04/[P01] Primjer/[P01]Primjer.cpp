#include<iostream>
#include"P01_Tocka.h"
using namespace std;

int main() {

	P01_Tocka Tocka;

	Tocka.SetX(1);
	Tocka.SetY(2);

	cout << "T(" << Tocka.GetX() << ", " << Tocka.GetY() << ") => " << Tocka.GetUdaljenost() << endl;


	//Drugi primjer
	P01_Tocka PoljeTocaka[5];
	int temp;

	for (int i = 0; i < 5; i++) {
		cout << "Upisite x koordinatu " << i+1 << ". tocke: ";
		cin >> temp;
		PoljeTocaka[i].SetX(temp);

		cout << "Upisite y koordinatu " << i + 1 << ". tocke: ";
		cin >> temp;
		PoljeTocaka[i].SetY(temp);
	}
	cout << "Upisali ste tocke:" << endl;
	for (int i = 0; i < 5; i++) {
		cout << "T(" << PoljeTocaka[i].GetX() << ", " << PoljeTocaka[i].GetY() << ")" << endl;
	}

	return 0;
}