#pragma once
class P01_Tocka {
	double x;
	double y;
public:
	P01_Tocka();

	void SetX(double x);
	void SetY(double y);

	double GetX();
	double GetY();

	double GetUdaljenost();
};

