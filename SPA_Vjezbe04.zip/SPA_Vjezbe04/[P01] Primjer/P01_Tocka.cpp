#include "P01_Tocka.h"

#include<cmath>

P01_Tocka::P01_Tocka() : x(0),y(0) {}

void P01_Tocka::SetX(double x) {
	if (x < 0) x = 0.0;
	this->x = x;
}

void P01_Tocka::SetY(double y) {
	if (y < 0) y = 0.0;
	this->y = y;
}

double P01_Tocka::GetX() {
	return this->x;
}

double P01_Tocka::GetY() {
	return this->y;
}

double P01_Tocka::GetUdaljenost() {
	return std::sqrt(std::pow(this->GetX(), 2) + std::pow(this->GetY(), 2));
}
