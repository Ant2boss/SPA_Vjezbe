#include "[01]Tocka.h"
#include <iostream>
#include <sstream>
#include<iomanip>

Tocka::Tocka() : x(0), y(0) {
}

void Tocka::init(int x, int y) {
	this->SetX(x);
	this->SetY(y);
}

void Tocka::SetX(int x) {
	if (x < 0) x = 0;
	this->x = x;
}

void Tocka::SetY(int y) {
	if (y < 0) y = 0;
	this->y = y;
}

int Tocka::GetX() {
	return this->x;
}

int Tocka::GetY() {
	return this->y;
}

double Tocka::GetUdaljenost() {
	return std::sqrt(std::pow(this->x, 2) + std::pow(this->y, 2));
}

std::string Tocka::to_string() {
	std::stringstream ss;
	ss << "d(" << this->GetX() << ", " << this->GetY() << ") = " << std::setprecision(12) <<this->GetUdaljenost() << std::endl;
	return ss.str();
}
