#include<iostream>
#include<iomanip>
#include<chrono>
#include<fstream>
#include"[01]Tocka.h"
using namespace std;

Tocka* prepare_array(int n) {
	Tocka* polje = new Tocka[n];

	for (int i = 0; i < n; i++) {
		polje[i].init(i, i);
	}

	return polje;
}

int main() {

	const int size = 100000;
	Tocka* TocPolje = prepare_array(size);

	ofstream out("Udaljenosti.txt");
	if (!out) {
		cout << "Greska 404" << endl;
		return -1;
	}

	auto begin = chrono::high_resolution_clock::now();

	for (int i = 0; i < size; i++) {
		out << setprecision(12) << TocPolje[i].to_string();
	}


	auto end = chrono::high_resolution_clock::now();
	cout << "Trajanje: " << chrono::duration_cast<std::chrono::milliseconds> (end - begin).count() << endl;

	out.close();
	delete[] TocPolje;
	return 0;
}