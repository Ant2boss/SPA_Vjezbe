#pragma once
#include<string>
class Tocka {
	int x;
	int y;
public:
	Tocka();

	void init(int x, int y);
	void SetX(int x);
	void SetY(int y);

	int GetX();
	int GetY();

	double GetUdaljenost();
	std::string to_string();
};

