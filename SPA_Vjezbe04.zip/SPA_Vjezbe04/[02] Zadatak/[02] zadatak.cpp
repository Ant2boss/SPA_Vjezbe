#include<iostream>
#include<chrono>
#include<ctime>
#include"funkcije_za_sortiranje.h"
using namespace std;

int genRand(int min, int max) {
	return (rand() % (max - min + 1)) + min;
}

int* PopuniPolje(const int size) {
	int* P1 = new int[size];
	for (int i = 0; i < size; i++) P1[i] = genRand(1, 1000);

	return P1;
}

int* KopirajPolje(int* P1, const int size) {
	int* P2 = new int[size];
	for (int i = 0; i < size; i++) P2[i] = P1[i];

	return P2;
}

int main() {

	srand(time(nullptr));

	const int size = 100000;

	int* Polje_QuickSort = PopuniPolje(size);
	int* Polje_BubbleSort = KopirajPolje(Polje_QuickSort, size);
	
	cout << "Sortiranje: ..." << endl;
	auto startQS = std::chrono::high_resolution_clock::now();
	
	quick_sort(Polje_QuickSort, size);

	auto endQS = std::chrono::high_resolution_clock::now();
	cout << "Quick Sort: " << std::chrono::duration_cast<std::chrono::microseconds> (endQS - startQS).count() << endl;
	
	cout << "Sortiranje: ..." << endl;
	auto startBS = std::chrono::high_resolution_clock::now();

	bubble_sort(Polje_BubbleSort, size);

	auto endBS = std::chrono::high_resolution_clock::now();
	cout << "Bubble Sort: " << std::chrono::duration_cast<std::chrono::microseconds> (endBS - startBS).count() << endl;

	delete[] Polje_QuickSort;
	delete[] Polje_BubbleSort;

	return 0;
}