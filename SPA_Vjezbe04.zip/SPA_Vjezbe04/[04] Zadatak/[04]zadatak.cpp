#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
using namespace std;

int main() {

	ifstream Ifile("Broj_znanstvenika_na_milijun_stanovnika.csv");
	ofstream Ofile("Rijesenje.bin", ios_base::binary);

	if (!Ifile) {
		cout << "Greska prilikom otvaranja!" << endl;
		return -1;
	}
	if (!Ofile) {
		cout << "Greska prilikom otvranja!" << endl;
		return -2;
	}

	string Redak;
	getline(Ifile, Redak);
	while (getline(Ifile, Redak)) {
		string NazivDrzave;
		stringstream ssRedak(Redak);

		getline(ssRedak, NazivDrzave, ';');
		int len = NazivDrzave.length();
		Ofile.write((char*)&len, sizeof(len));	//Duljina stringa
		Ofile.write(NazivDrzave.c_str(), NazivDrzave.length());	//String
	}

	Ifile.close();
	Ofile.close();
	return 0;
}