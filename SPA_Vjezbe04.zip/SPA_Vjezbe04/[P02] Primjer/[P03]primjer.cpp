#include<iostream>
#include<ctime>
using namespace std;

int genRandom(int donjaGranica, int gornjaGranica) {
	return rand() % (gornjaGranica - donjaGranica + 1) + donjaGranica;
}

int main() {

	srand(time(nullptr));

	cout << "Cestitamo!" << endl;
	cout << "Stvorili ste broj: " << genRandom(1, 100) << endl;
	cout << "Vi ste prvi u svijetu koji su taj broj dobili!" << endl;

	return 0;
}