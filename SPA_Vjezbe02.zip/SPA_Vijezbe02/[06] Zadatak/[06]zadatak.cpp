#include<iostream>
#include<string>
#include<fstream>
#include<array>
using namespace std;

int main() {

	ifstream inFile("NekiTekst.txt");

	array<string, 500> Rijeci;

	if (!inFile) {
		cout << "Greska prilikom otvaranja!" << endl;
	}

	int Br_Rijeci = 0;
	string R;

	while (inFile >> R) {
		Rijeci[Br_Rijeci] = R;
		Br_Rijeci++;
	}
	inFile.close();

	int TheCounter = 0;

	for (int i = 0; i < Br_Rijeci; i++) {
		if (Rijeci[i] == "the") TheCounter++;
	}

	cout << "Rijec 'the' se pojavljuje: " << TheCounter << " puta!" << endl;
	return 0;
}