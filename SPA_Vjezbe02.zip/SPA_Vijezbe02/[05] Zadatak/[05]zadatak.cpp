#include<iostream>
#include<array>
using namespace std;

bool Prost(int broj) {
	for (int i = 2; i < broj; i++) {
		if (broj % i == 0) return false;
	}
	return (broj != 1);
}

void IspisiProste(int& broj) {
	if (Prost(broj)) cout << broj << endl;
}

int main() {

	array<int, 100> arr;
	for (int i = 0; i < arr.size(); i++) arr[i] = i + 1;

	for_each(arr.begin(), arr.end(), IspisiProste);

	return 0;
}