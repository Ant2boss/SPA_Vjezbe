#include<iostream>
#include<fstream>
#include<string>
#include<vector>
using namespace std;

bool Uvijet(string& rijec) {
	if (rijec == "the") return true;
	else return false;
}

int main() {
	vector<string> Rijeci;

	ifstream inFile("NekiTekst.txt");
	if (!inFile) {
		cout << "Greska prilikom otvranja!" << endl;
		return -1;
	}


	string R;
	while (inFile >> R) {
		Rijeci.push_back(R);
	}

	inFile.close();
	
	int brThe = 0;
	for (int i = 0; i < Rijeci.size(); i++) {
		if (Rijeci[i].find("the") != string::npos) {
			if (Rijeci[i] == "the") brThe++;
		}
	}

	cout << "Rijec the se pojavljuje: " << brThe << " puta!" << endl;

	return 0;
}