#include<iostream>
#include<string>
#include<fstream>
using namespace std;

void out_File(const char* FileName) {
	ifstream inFile(FileName);

	if (!inFile) throw runtime_error("Nije uspjelo otvoriti datoteku!");

	string str;
	while (getline(inFile, str)) {
		cout << str << endl;
	}

	inFile.close();
}

int main() {
	string Name;
	cout << "Upsite ime datoteke:";
	getline(cin, Name);

	try {
		out_File(Name.c_str());
	}
	catch (exception& err) {
		cout << err.what() << endl;
	}
	return 0;
}