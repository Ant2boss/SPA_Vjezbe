#include "[04]Pravokutnik.h"
#include<iostream>
#include<sstream>

Pravokutnik::Pravokutnik(int sirina, int visina) {
	if (sirina < 0) throw runtime_error("Sirina mora biti veca od 0!");
	if (visina < 0) throw runtime_error("Visina mora biti veca od 0!");

	this->Sirina = sirina;
	this->Visina = visina;
}

string Pravokutnik::Get_PravokutnikString(char Znak_Rub, char Znak_Sadrzaj, bool CrtajSadrzaj) {
	stringstream ss;
	for (int y = 0; y < this->Visina; y++) {
		for (int x = 0; x < this->Sirina; x++) {
			if (x == 0 || y == 0 || x == this->Sirina - 1 || y == this->Visina - 1) ss << Znak_Rub;
			else if (CrtajSadrzaj) ss << Znak_Sadrzaj;
			else ss << " ";
		}
		ss << endl;
	}

	return ss.str();
}
