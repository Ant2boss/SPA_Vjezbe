#pragma once
#include<string>
using namespace std;

class Pravokutnik {
private:
	int Sirina;
	int Visina;
public:
	Pravokutnik(int sirina, int visina);

	string Get_PravokutnikString(char Znak_Rub, char Znak_Sadrzaj, bool CrtajSadrzaj);
};

