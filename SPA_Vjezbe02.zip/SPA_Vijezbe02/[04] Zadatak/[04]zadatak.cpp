#include<iostream>
#include"[04]Pravokutnik.h"
using namespace std;

int main() {

	Pravokutnik P(64,32);

	cout << P.Get_PravokutnikString('A', '.', false);


	return 0;
}