#include "[03]Lampa.h"
#include<sstream>

Lampa::Lampa() {
	this->Set_BrojSijalica(0);
	this->Set_Snaga(0.0);
}

Lampa::Lampa(const string NazivModela) : Lampa() {
	this->Set_NazivModela(NazivModela);
}

void Lampa::Set_NazivModela(const string NazivModela) {
	this->NazivModela = NazivModela;
}

void Lampa::Set_NazivProizvodaca(const string Proizvodac) {
	this->NazivProizvodaca = Proizvodac;
}

void Lampa::Set_BrojSijalica(const int BrojSijalica) {
	if (BrojSijalica < 0) this->BrojSijalica = 0;
	else this->BrojSijalica = BrojSijalica;
}

void Lampa::Set_Snaga(const double Snaga) {
	this->Snaga = Snaga;
}

string Lampa::Get_Model() const {
	return this->NazivModela;
}

string Lampa::Get_Proizvodac() const {
	return this->NazivProizvodaca;
}

int Lampa::Get_BrojSijalica() const {
	return this->BrojSijalica;
}

double Lampa::Get_Snaga() const {
	return this->Snaga;
}

string Lampa::toString() {
	stringstream ss;
	ss << "Proizvodac: " << this->Get_Proizvodac() << "/ Model: " << this->Get_Model() << "/ Broj sijalica: " << this->Get_BrojSijalica() << "/ Snaga: " << this->Get_Snaga() << endl;
	return ss.str();
}
