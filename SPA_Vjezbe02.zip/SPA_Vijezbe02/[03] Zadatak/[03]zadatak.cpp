#include"[03]Lampa.h"
#include<iostream>
using namespace std;

int main() {

	Lampa L;
	L.Set_NazivModela("Miro");
	L.Set_NazivProizvodaca("Miric");
	L.Set_BrojSijalica(23);
	L.Set_Snaga(4.20);

	Lampa L2("Maro");
	L2.Set_NazivProizvodaca("Netkic");
	L2.Set_BrojSijalica(4);
	L2.Set_Snaga(6.9);

	cout << L.toString();
	cout << L2.toString();

	return 0;
}