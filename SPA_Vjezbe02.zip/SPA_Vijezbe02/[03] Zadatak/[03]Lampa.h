#pragma once
#include<string>
using namespace std;

class Lampa {
private:
	string NazivModela;
	string NazivProizvodaca;
	int BrojSijalica;
	double Snaga;
public:
	Lampa();
	Lampa(const string NazivModela);

	void Set_NazivModela(const string NazivModela);
	void Set_NazivProizvodaca(const string Proizvodac);
	void Set_BrojSijalica(const int BrojSijalica);
	void Set_Snaga(const double Snaga);

	string Get_Model() const;
	string Get_Proizvodac() const;
	int Get_BrojSijalica() const;
	double Get_Snaga() const;

	string toString();
};

