#include<iostream>
using namespace std;

int MUL(int a, int b) {
	return a * b;
}
int DIV(int a, int b) {
	if (b == 0) throw runtime_error("Nije moguce dijeliti sa 0!");
	return a / b;
}
int ROOT(int a) {
	if (a < 0) throw runtime_error("Nije moguce korijenovati negativne brojeve");
	return sqrt(a);
}

int main() {
	int a, b;
	cout << "Ucitajte prvi broj: " << endl;
	cin >> a;

	cout << "Ucitajte drugi broj: " << endl;
	cin >> b;

	try {
		cout << a << "*" << b << "=" << MUL(a, b) << endl;
	}
	catch (exception& err) {
		cout << err.what() << endl;
	}
	try {
		cout << a << "/" << b << "=" << DIV(a, b) << endl;
	}
	catch (exception& err) {
		cout << err.what() << endl;
	}
	try {
		cout << "Root: " << a << "=" << ROOT(a) << endl;
	}
	catch (exception& err) {
		cout << err.what() << endl;
	}
	return 0;
}