#pragma once
class Z09_MojVektorChar {
	char PoljeSlova[10];
	int Size;
	int Capacitiy = 10;
public:
	Z09_MojVektorChar();

	void push_back(char Slovo);
	int size();
	char& at(int index);
};

