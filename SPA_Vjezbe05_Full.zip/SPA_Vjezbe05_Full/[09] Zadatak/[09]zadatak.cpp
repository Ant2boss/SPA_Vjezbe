#include<iostream>
#include"Z09_MojVektorChar.h"
using namespace std;

int main() {

	Z09_MojVektorChar v;
	v.push_back('a');
	for (int i = 0; i < v.size(); i++) cout << v.at(i) << endl;

	v.push_back('b');
	for (int i = 0; i < v.size(); i++) cout << v.at(i) << endl;

	v.push_back('c');
	for (int i = 0; i < v.size(); i++) cout << v.at(i) << endl;

	return 0;
}