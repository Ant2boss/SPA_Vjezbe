#include "Z09_MojVektorChar.h"

Z09_MojVektorChar::Z09_MojVektorChar() {
	for (int i = 0; i < 10; i++) this->PoljeSlova[i] = 0;
	this->Size = 0;
}

void Z09_MojVektorChar::push_back(char Slovo) {
	if (Size == 10) return;
	
	this->PoljeSlova[this->Size] = Slovo;
	this->Size++;
}

int Z09_MojVektorChar::size() {
	return this->Size;
}

char& Z09_MojVektorChar::at(int index) {
	return this->PoljeSlova[index];
}
