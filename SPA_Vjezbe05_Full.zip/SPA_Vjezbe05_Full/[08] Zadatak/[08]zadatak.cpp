#include"..\[07] Zadatak\Z07_IPadresa.h"
#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
using namespace std;

int PretvoriUBroj(string Broj) {
	int b;
	stringstream ssBroj(Broj);

	ssBroj >> b;

	return b;
}

void IspisiBrojKlasi(char klasa, vector<Z07_IPadresa>& IP) {
	cout << "Klasa " << klasa << ": ";
	int count = 0;
	for (int i = 0; i < IP.size(); i++) {
		if (IP[i].PripadaKlasi() == klasa) {
			cout << "#"; 
			count++;
		}
	}
	cout << " (" << count << ")" << endl;
}

int main() {

	ifstream inFile("ip_adrese.txt");

	if (!inFile) {
		cout << "Greska!" << endl;
		return -1;
	}

	string CijeliIP;
	vector<Z07_IPadresa> PoljeIP;
	while (getline(inFile, CijeliIP)) {
		stringstream ssIP(CijeliIP);
		Z07_IPadresa temp;

		string oktet;
		getline(ssIP, oktet, '.');
		temp.SetOktet(0, PretvoriUBroj(oktet));
		getline(ssIP, oktet, '.');
		temp.SetOktet(1, PretvoriUBroj(oktet));
		getline(ssIP, oktet, '.');
		temp.SetOktet(2, PretvoriUBroj(oktet));
		getline(ssIP, oktet);
		temp.SetOktet(3, PretvoriUBroj(oktet));

		PoljeIP.push_back(temp);
	}

	inFile.close();

	IspisiBrojKlasi('A', PoljeIP);
	IspisiBrojKlasi('B', PoljeIP);
	IspisiBrojKlasi('C', PoljeIP);
	IspisiBrojKlasi('D', PoljeIP);
	IspisiBrojKlasi('E', PoljeIP);
	

	return 0;
}