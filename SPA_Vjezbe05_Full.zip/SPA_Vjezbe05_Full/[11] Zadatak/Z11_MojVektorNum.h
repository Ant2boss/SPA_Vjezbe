#pragma once
class Z11_MojVektorNum {
	int PoljeBrojeva[100];
	int Capacity = 100;
	int Size = 0;
public:
	void push_back(int Broj);

	class iterator {
		int* p;
	public:
		iterator(int* SetPoint);

		int operator* ();
		void operator++ ();
		bool operator == (iterator compare);
		bool operator != (iterator compare);
	};

	class riterator {
		int* rp;
	public:
		riterator(int* SetPoint);

		int operator* ();
		void operator++ ();
		bool operator==(riterator rCompare);
		bool operator!=(riterator rCompare);
	};

	iterator begin();
	iterator end();

	riterator rbegin();
	riterator rend();
};

