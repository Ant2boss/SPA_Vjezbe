#include "Z11_MojVektorNum.h"

void Z11_MojVektorNum::push_back(int Broj) {
	if (this->Size == this->Capacity) return;

	this->PoljeBrojeva[this->Size] = Broj;
	this->Size++;
}

Z11_MojVektorNum::iterator Z11_MojVektorNum::begin() {
	return iterator(&this->PoljeBrojeva[0]);
}

Z11_MojVektorNum::iterator Z11_MojVektorNum::end() {
	return iterator(&this->PoljeBrojeva[this->Size]);
}

Z11_MojVektorNum::riterator Z11_MojVektorNum::rbegin() {
	return riterator(&this->PoljeBrojeva[this->Size - 1]);
}

Z11_MojVektorNum::riterator Z11_MojVektorNum::rend() {
	return riterator(&this->PoljeBrojeva[-1]);
}

Z11_MojVektorNum::iterator::iterator(int* SetPoint) {
	this->p = SetPoint;
}

int Z11_MojVektorNum::iterator::operator*() {
	return (*this->p);
}

void Z11_MojVektorNum::iterator::operator++() {
	++this->p;
}

bool Z11_MojVektorNum::iterator::operator==(iterator compare) {
	return (this->p == compare.p);
}

bool Z11_MojVektorNum::iterator::operator!=(iterator compare) {
	return (this->p != compare.p);
}

Z11_MojVektorNum::riterator::riterator(int* SetPoint) {
	this->rp = SetPoint;
}

int Z11_MojVektorNum::riterator::operator*() {
	return *(this->rp);
}

void Z11_MojVektorNum::riterator::operator++() {
	--this->rp;
}

bool Z11_MojVektorNum::riterator::operator==(riterator rCompare) {
	return this->rp == rCompare.rp;
}

bool Z11_MojVektorNum::riterator::operator!=(riterator rCompare) {
	return this->rp != rCompare.rp;
}
