#include<iostream>
#include"Z11_MojVektorNum.h"

using namespace std;

int main() {

	Z11_MojVektorNum v;

	for (int i = 0; i < 10; i++) {
		v.push_back((i + 1) * 10);
	}

	for (Z11_MojVektorNum::iterator it = v.begin(); it != v.end(); ++it) {
		cout << *it << endl;
	}

	for (auto it = v.rbegin(); it != v.rend(); ++it) {
		cout << *it << endl;
	}

	return 0;
}