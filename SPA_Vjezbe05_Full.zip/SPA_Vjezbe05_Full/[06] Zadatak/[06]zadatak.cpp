#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include"Z06_Osoba.h"
using namespace std;

int main() {

	ifstream InputFile("kontakti.txt");

	if (!InputFile) {
		cout << "Greska kod otvaranja!" << endl;
		return -1;
	}

	vector<Z06_Osoba> PoljeOsoba;
	string ImePrezime;
	while (getline(InputFile, ImePrezime)) {
		stringstream ssImePrezime(ImePrezime);
		string Ime;
		getline(ssImePrezime, Ime, ';');
		string Prezime;
		getline(ssImePrezime, Prezime);

		Z06_Osoba temp;
		temp.SetIme(Ime);
		temp.SetPrezime(Prezime);

		PoljeOsoba.push_back(temp);
	}

	InputFile.close();

	char pret;
	cout << "Osobe ucitane iz imenika!" << endl;
	cout << "Upisite prvo slovo imena ili prezimena osobe koju zelite vidjeti: ";
	cin >> pret;

	cout << endl << "Sve osobe cije ime ili prezime pocinje sa [" << pret << "]:" << endl;
	for (int i = 0; i < PoljeOsoba.size(); i++) {
		if (PoljeOsoba[i].ZapocinjeSlovom(pret)) {
			cout << PoljeOsoba[i].GetIme() << " " << PoljeOsoba[i].GetPrezime() << endl;
		}
	}
	return 0;
}