#include "Z06_Osoba.h"

void Z06_Osoba::SetIme(std::string ime) {
	this->Ime = ime;
}

void Z06_Osoba::SetPrezime(std::string prezime) {
	this->Prezime = prezime;
}

std::string Z06_Osoba::GetIme() const {
	return this->Ime;
}

std::string Z06_Osoba::GetPrezime() const {
	return this->Prezime;
}

bool Z06_Osoba::ZapocinjeSlovom(char Slovo) const {
	if (this->Ime[0] == Slovo) return true;
	if (this->Prezime[0] == Slovo) return true;

	return false;
}
