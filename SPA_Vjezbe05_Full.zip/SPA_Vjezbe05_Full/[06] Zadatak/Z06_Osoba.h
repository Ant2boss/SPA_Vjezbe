#pragma once
#include<string>
class Z06_Osoba {
	std::string Ime;
	std::string Prezime;
public:
	void SetIme(std::string ime);
	void SetPrezime(std::string prezime);

	std::string GetIme() const;
	std::string GetPrezime() const;

	bool ZapocinjeSlovom(char Slovo) const;
};

