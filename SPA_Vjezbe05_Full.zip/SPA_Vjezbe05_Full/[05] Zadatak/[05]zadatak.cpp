#include<iostream>
#include<chrono>
#include<vector>
using namespace std;

int main() {

	vector<int> UbacivanjePocetak;

	cout << "Ubacivanje na pocetak traje: ";
	auto VrijemePoc = chrono::high_resolution_clock::now();

	for (int i = 0; i < 100000; i++) {
		UbacivanjePocetak.insert(UbacivanjePocetak.begin(), i);
	}

	auto VrijemeKraj = chrono::high_resolution_clock::now();
	cout << chrono::duration_cast<chrono::milliseconds> (VrijemeKraj - VrijemePoc).count() << "ms!" <<endl;

	vector<int> Kraj;

	cout << "Ubacivanje na kraj traje: ";
	VrijemePoc = chrono::high_resolution_clock::now();

	for (int i = 0; i < 100000; i++) Kraj.push_back(i);

	VrijemeKraj = chrono::high_resolution_clock::now();
	cout << chrono::duration_cast<chrono::milliseconds> (VrijemeKraj - VrijemePoc).count() << "ms!" << endl;

	return 0;
}