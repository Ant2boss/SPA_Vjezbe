#pragma once
class Z07_IPadresa {
	int oktet[4];
public:
	void SetOktet(int Oktet, int val);

	int GetOktet(int Oktet);

	char PripadaKlasi();
};

