#include "Z07_IPadresa.h"

void Z07_IPadresa::SetOktet(int Oktet, int val) {
	this->oktet[Oktet] = val;
}

int Z07_IPadresa::GetOktet(int Oktet) {
	return this->oktet[Oktet];
}

char Z07_IPadresa::PripadaKlasi() {
	if (this->oktet[0] <= 126) return 'A';
	else if (this->oktet[0] <= 191) return 'B';
	else if (this->oktet[0] <= 223) return 'C';
	else if (this->oktet[0] <= 239) return 'D';
	else if (this->oktet[0] <= 254) return 'E';
}
