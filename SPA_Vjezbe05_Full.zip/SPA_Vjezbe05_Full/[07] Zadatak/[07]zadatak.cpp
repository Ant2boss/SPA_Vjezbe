#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include"Z07_IPadresa.h"
using namespace std;

int PretvoriUBroj(string Broj) {
	int b;
	stringstream ssBroj(Broj);

	ssBroj >> b;

	return b;
}

int main() {

	ifstream inFile("ip_adrese.txt");

	if (!inFile) {
		cout << "Greska!" << endl;
		return -1;
	}

	string CijeliIP;
	vector<Z07_IPadresa> PoljeIP;
	while (getline(inFile, CijeliIP)) {
		stringstream ssIP(CijeliIP);
		Z07_IPadresa temp;

		string oktet;
		getline(ssIP, oktet, '.');
		temp.SetOktet(0, PretvoriUBroj(oktet));
		getline(ssIP, oktet, '.');
		temp.SetOktet(1, PretvoriUBroj(oktet));
		getline(ssIP, oktet, '.');
		temp.SetOktet(2, PretvoriUBroj(oktet));
		getline(ssIP, oktet);
		temp.SetOktet(3, PretvoriUBroj(oktet));

		PoljeIP.push_back(temp);
	}

	inFile.close();

	for (int i = 0; i < PoljeIP.size(); i++) {
		if (PoljeIP[i].PripadaKlasi() == 'C') {
			for (int j = 0; j < 4; j++) cout << PoljeIP[i].GetOktet(j) << " ";
			cout << endl;
		}
	}

	return 0;
}