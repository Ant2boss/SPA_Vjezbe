#include<iostream>
#include<vector>
#include<fstream>
#include<string>
#include<sstream>
#include"Z02_Tocka.h"
using namespace std;

int main() {

	ifstream inputFile("tocke.txt");
	if (!inputFile) {
		cout << "Greska pirlikom otvranja!" << endl;
		return -1;
	}

	vector<Z02_Tocka> PoljeTocaka;

	string redak;
	while (getline(inputFile, redak)) {
		stringstream ssRedak(redak);
		int temp;
		Z02_Tocka tempToc;
		ssRedak >> temp;
		tempToc.SetX(temp);

		ssRedak >> temp;
		tempToc.SetY(temp);

		ssRedak >> temp;
		tempToc.SetZ(temp);

		if (tempToc.TockaJeIspravna()) PoljeTocaka.push_back(tempToc);
	}

	inputFile.close();

	cout << "U polje je ubaceno: " << endl;
	for (auto it = PoljeTocaka.begin(); it != PoljeTocaka.end(); ++it) {
		cout << it->GetX() << "/" << it->GetY() << "/" << it->GetZ() << endl;
	}
	return 0;
}