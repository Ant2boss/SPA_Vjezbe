#pragma once
class Z02_Tocka {
	int x;
	int y;
	int z;
public:
	void SetX(int x);
	void SetY(int y);
	void SetZ(int z);
	void SetXYZ(int x, int y, int z);

	bool TockaJeIspravna();

	int GetX();
	int GetY();
	int GetZ();
};

