#include "Z02_Tocka.h"

void Z02_Tocka::SetX(int x) {
	this->x = x;
}

void Z02_Tocka::SetY(int y) {
	this->y = y;
}

void Z02_Tocka::SetZ(int z) {
	this->z = z;
}

void Z02_Tocka::SetXYZ(int x, int y, int z) {
	this->SetX(x);
	this->SetY(y);
	this->SetZ(z);
}

bool Z02_Tocka::TockaJeIspravna() {
	if (this->x < 0) return false;
	if (this->y < 0) return false;
	if (this->z < 0) return false;

	return true;
}

int Z02_Tocka::GetX() {
	return this->x;
}

int Z02_Tocka::GetY() {
	return this->y;
}

int Z02_Tocka::GetZ() {
	return this->z;
}
