#include<iostream>
#include<vector>
using namespace std;

int main() {

	vector<int> PoljeBrojeva;

	int CapVektora = PoljeBrojeva.capacity();

	for (int i = 0; i < 500; i++) {
		PoljeBrojeva.push_back(i);

		if (PoljeBrojeva.capacity() != CapVektora) {
			CapVektora = PoljeBrojeva.capacity();
			cout << "S: " << PoljeBrojeva.size() << " / " << "C: " << PoljeBrojeva.capacity() << endl;
		}
	}

	return 0;
}