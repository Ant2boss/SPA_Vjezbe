#pragma once
#include<string>

class Z10_MojVektorString {
	std::string* PoljeStringova = nullptr;
	int Size;
	int Capacitiy;

	void AlocirajMemoriju();
	void OtpustiMemoriju();

public:
	Z10_MojVektorString(int Kol, std::string Val);
	~Z10_MojVektorString();

	void push_back(std::string Umetni);
	int size();
	int capacity();
	std::string& at(int index);

};

