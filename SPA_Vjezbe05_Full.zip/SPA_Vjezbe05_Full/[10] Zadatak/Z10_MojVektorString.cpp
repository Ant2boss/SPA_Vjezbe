#include "Z10_MojVektorString.h"

void Z10_MojVektorString::AlocirajMemoriju() {
	if (this->PoljeStringova == nullptr) { 
		this->PoljeStringova = new std::string[this->Capacitiy]; 
		return;
	}

	const int PovecajZa = 5;

	std::string* tempPoint = new std::string[this->Capacitiy + PovecajZa];
	for (int i = 0; i < this->Size; i++) {
		tempPoint[i] = this->PoljeStringova[i];
	}
	delete[] this->PoljeStringova;
	this->PoljeStringova = tempPoint;
	this->Capacitiy += PovecajZa;
}

void Z10_MojVektorString::OtpustiMemoriju() {
	if (this->PoljeStringova != nullptr) delete[] this->PoljeStringova;
}

Z10_MojVektorString::Z10_MojVektorString(int Kol, std::string Val) {
	this->Capacitiy = Kol;
	this->Size = Kol;
	this->AlocirajMemoriju();
	for (int i = 0; i < this->Size; i++) this->PoljeStringova[i] = Val;
}

Z10_MojVektorString::~Z10_MojVektorString() {
	this->OtpustiMemoriju();
}

void Z10_MojVektorString::push_back(std::string Umetni) {
	if (Size == Capacitiy) this->AlocirajMemoriju();

	this->PoljeStringova[Size] = Umetni;
	Size++;
}

int Z10_MojVektorString::size() {
	return this->Size;
}

int Z10_MojVektorString::capacity() {
	return this->Capacitiy;
}

std::string& Z10_MojVektorString::at(int index) {
	return this->PoljeStringova[index];
}
