#include<iostream>
#include<vector>
#include<ctime>
using namespace std;

int GenRand(int min, int max) {
	return rand() % (max + min + 1) + min;
}

void IspisiCapSiz(vector<int>& V) {
	cout << "S: " << V.size() << " / C: " << V.capacity() << endl;
}

int main() {

	vector<int> PoljeBrojeva;
	srand(time(nullptr));

	//Tocka 1
	PoljeBrojeva.reserve(100);
	IspisiCapSiz(PoljeBrojeva);

	//Tocka 2
	for (int i = 0; i < 100; i++) {
		PoljeBrojeva.insert(PoljeBrojeva.begin(), GenRand(1, 100));
	}
	for (int i = 0; i < PoljeBrojeva.size(); i++) {
		cout << "[" << PoljeBrojeva.at(i) << "]";
 	}
	cout << endl;
	IspisiCapSiz(PoljeBrojeva);

	//Tocka 3
	PoljeBrojeva.resize(50);
	for (auto it = PoljeBrojeva.begin(); it != PoljeBrojeva.end(); ++it) {
		cout << "[" << *it << "]";
	}
	cout << endl;
	IspisiCapSiz(PoljeBrojeva);

	//Tocka 4
	PoljeBrojeva.reserve(30);
	for (auto it = PoljeBrojeva.rbegin(); it != PoljeBrojeva.rend(); ++it) {
		cout << "[" << *it << "]";
	}
	cout << endl;
	IspisiCapSiz(PoljeBrojeva);

	//Tocka 5
	vector<int> NovoPolje;
	NovoPolje.reserve(30);

	NovoPolje = PoljeBrojeva;

	//Tocka 6
	PoljeBrojeva.clear();
	IspisiCapSiz(PoljeBrojeva);

	//Tocka 7
	NovoPolje.erase(NovoPolje.begin(), NovoPolje.begin() + 10);
	cout << "[" << NovoPolje.front() << "][" << NovoPolje.back() << "]" << endl;
	IspisiCapSiz(NovoPolje);

	//Tocka 8
	for (auto it = NovoPolje.begin(); it != NovoPolje.end();) {
		it = NovoPolje.erase(NovoPolje.begin());
	}
	IspisiCapSiz(NovoPolje);

	return 0;
}