#pragma once
#include<string>
using namespace std;

class Z03_MojVektor {

	string PoljeStringa[50];
	int Size;
	int Capacitiy = 50;

public:
	Z03_MojVektor(int Size);
	Z03_MojVektor(int Size, string Val);

	int size();
	string& at(int index);

};

