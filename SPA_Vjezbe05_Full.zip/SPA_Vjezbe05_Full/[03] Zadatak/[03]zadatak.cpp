#include<iostream>
#include"Z03_MojVektor.h"
using namespace std;

int main() {

	Z03_MojVektor v(10, "Helooooo!");

	for (int i = 0; i < v.size(); i++) {
		cout << v.at(i) << endl;
	}

	return 0;
}