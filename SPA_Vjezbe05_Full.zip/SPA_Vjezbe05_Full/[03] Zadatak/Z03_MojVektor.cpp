#include "Z03_MojVektor.h"

Z03_MojVektor::Z03_MojVektor(int Size) {
	this->Size = Size;
}

Z03_MojVektor::Z03_MojVektor(int Size, string Val) : Z03_MojVektor(Size) {
	for (int i = 0; i < this->Size; i++) {
		this->PoljeStringa[i] = Val;
	}
}

int Z03_MojVektor::size() {
	return this->Size;
}

string& Z03_MojVektor::at(int index) {

	if (index < 0 || index >= this->Size) throw "Greska!";

	return this->PoljeStringa[index];
}
