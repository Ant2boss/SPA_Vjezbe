#include<iostream>
#include<fstream>
#include"[02]Pravokutnik.h"
using namespace std;

Pravokutnik UcitajPravokutnik() {
	Pravokutnik temp;
	int t;
	cout << "Upisite visinu pravokutnika: ";
	cin >> t;
	temp.Set_Visina(t);

	cout << "Upisite sirinu pravokutnika: ";
	cin >> t;
	temp.Set_Sirina(t);

	return temp;
}

int main() {

	Pravokutnik P[5];
	
	for (int i = 0; i < 5; i++) {
		cout << "Pravokuntik " << i+1 << ":" << endl;
		P[i] = UcitajPravokutnik();
	}

	ofstream OUT("Pravokutnici.txt");

	if (!OUT) {
		cout << "Greska prilikom otvaranja!" << endl;
		return 1;
	}

	for (int i = 0; i < 5; i++) {
		P[i].Out_to_File(OUT);
	}

	OUT.close();

	return 0;
}