#pragma once

#include<fstream>
using namespace std;
class Pravokutnik
{
private:
	int Sirina;
	int Visina;
public:
	void Set_Sirina(int sirina);
	void Set_Visina(int visina);

	int Get_Sirina();
	int Get_Visina();
	int Get_Povrisna();

	void StvoriPravokutnik(int sirina, int visina);
	void Out_to_File(ofstream& File);
};

