#include "[02]Pravokutnik.h"

void Pravokutnik::Set_Sirina(int sirina)
{
	if (sirina < 0) sirina = 0;
	this->Sirina = sirina;
}

void Pravokutnik::Set_Visina(int visina)
{
	if (visina < 0) visina = 0;
	this->Visina = visina;
}

int Pravokutnik::Get_Sirina()
{
	return this->Sirina;
}

int Pravokutnik::Get_Visina()
{
	return this->Visina;
}

int Pravokutnik::Get_Povrisna()
{
	return (this->Visina * this->Sirina);
}

void Pravokutnik::StvoriPravokutnik(int sirina, int visina)
{	
	this->Set_Sirina(sirina);
	this->Set_Visina(visina);
}

void Pravokutnik::Out_to_File(ofstream& File)
{
	File << "P(" << this->Get_Sirina() << ", " << this->Get_Visina() << ") =" << this->Get_Povrisna() << endl;
}
