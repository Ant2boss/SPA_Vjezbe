#pragma once
#include<string>
class Mijenjac
{
	int stanje;
	void Set_Stanje(int s);
public:
	Mijenjac(int PocStanje);

	void Gore_Brzina();
	void Dolje_Brzina();

	std::string string_Out();

};

