#include "[04]Mijenjac.h"
#include<sstream>

void Mijenjac::Set_Stanje(int s)
{
	if (s > 5) s = 5;
	else if (s < 0) s = 0;

	this->stanje = s;
}

Mijenjac::Mijenjac(int PocStanje)
{
	this->Set_Stanje(PocStanje);
}

void Mijenjac::Gore_Brzina()
{
	this->stanje++;

	if (this->stanje > 5) this->stanje--;
}

void Mijenjac::Dolje_Brzina()
{
	this->stanje--;
	
	if (this->stanje < 0) this->stanje++;
}

std::string Mijenjac::string_Out()
{
	std::stringstream ss;
	switch (this->stanje) {
	case 0:
		ss << "*zzz*";
		break;
	case 1:
		ss << "R";
		break;
	case 2:
		ss << "Rr";
		break;
	case 3:
		ss << "Rrr";
		break;
	case 4:
		ss << "Brrrm";
		break;
	case 5:
		ss << "Brrrrrrrrrrrrrrrrrm!";
		break;
	}
	return ss.str();
}
