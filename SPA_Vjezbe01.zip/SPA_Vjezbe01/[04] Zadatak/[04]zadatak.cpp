#include<iostream>
#include"[04]Mijenjac.h"
using namespace std;

int main() {
	Mijenjac M(0);

	cout << M.string_Out() << endl;
	M.Gore_Brzina();
	cout << M.string_Out() << endl;
	M.Gore_Brzina();
	cout << M.string_Out() << endl;
	M.Gore_Brzina();
	cout << M.string_Out() << endl;
	M.Gore_Brzina();
	cout << M.string_Out() << endl;
	M.Gore_Brzina();
	cout << M.string_Out() << endl;
	M.Gore_Brzina();
	cout << M.string_Out() << endl;
	M.Gore_Brzina();

	return 0;
}