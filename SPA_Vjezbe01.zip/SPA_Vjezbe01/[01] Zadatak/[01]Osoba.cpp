#include "[01]Osoba.h"
#include<sstream>

Osoba::Osoba(string Ime, string Prezime)
{
	this->ime = Ime;
	this->prezime = Prezime;
}

Osoba::Osoba(string Ime, string Prezime, string OIB) : Osoba(Ime, Prezime)
{
	this->Set_OIB(OIB);
}

string Osoba::to_string()
{
	stringstream ss;
	ss << this->prezime << ", " << this->ime << "(" << this->OIB << ")";
	
	return ss.str();
}

string Osoba::NacrtajOsobu()
{
	stringstream ss;
	
	ss << "      \\|||/" << endl;
	ss << "      (o o)" << endl;
	ss << ",~ooO~~(_)~~~~~~," << endl;
	ss << "|               |" << endl;
	ss << "|" << this->ime << " " << this->prezime;

	int l = this->ime.length() + this->prezime.length();
	for (int i = l; i < 14; i++) {
		ss << " ";
	}
	ss << "|" << endl;
	ss << "|               |" << endl;
	ss << ",~~~~~~~~~~~ooO~," << endl;
	ss << "     |__|__|" << endl;
	ss << "      || ||" << endl;
	ss << "     ooO Ooo" << endl;


	return ss.str();
}

void Osoba::Set_OIB(string OIB)
{
	this->OIB = OIB;
}
