#include<iostream>
#include"[01]Osoba.h"
using namespace std;

int main() {
	Osoba O("Antonio", "Klasic", "129312");


	cout << O.to_string() << endl;

	cout << O.NacrtajOsobu();
	
	return 0;
}