#pragma once

#include<string>
using namespace std;

class Osoba
{
private:
	string ime;
	string prezime;
	string OIB;
public:
	Osoba(string Ime, string Prezime);
	Osoba(string Ime, string Prezime, string OIB);
	
	string to_string();
	string NacrtajOsobu();

	void Set_OIB(string OIB);
};

