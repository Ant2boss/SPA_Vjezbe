#include "[03]Razlomak.h"
#include<sstream>

Razlomak::Razlomak()
{
	this->Brojnik = 1;
	this->Nazivnik = 1;
}

void Razlomak::Set_Brojnik(int vrijednost)
{
	this->Brojnik = vrijednost;
}

void Razlomak::Set_Nazivnik(int vrijednost)
{
	this->Nazivnik = vrijednost;
}

void Razlomak::Set_Razlomak(int Brojnik, int Nazivnik)
{
	this->Set_Brojnik(Brojnik);
	this->Set_Nazivnik(Nazivnik);
}

void Razlomak::Pomnozi(int skalar)
{
	this->Brojnik *= skalar;
}

std::string Razlomak::to_string()
{
	std::stringstream ss;

	ss << this->Brojnik << "/" << this->Nazivnik;

	return ss.str();
}
