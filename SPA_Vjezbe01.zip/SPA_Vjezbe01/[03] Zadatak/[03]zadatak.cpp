#include<iostream>
#include"[03]Razlomak.h"
using namespace std;

Razlomak UcitajRazlomak() {
	Razlomak t;
	int temp;
	cout << "Upisite brojnik: ";
	cin >> temp;
	t.Set_Brojnik(temp);

	cout << "Upisite nazivnik: ";
	cin >> temp;
	t.Set_Nazivnik(temp);

	return t;
}

int main() {
	bool provjera;

	do {
		Razlomak R;
		R = UcitajRazlomak();

		int skalar;
		cout << "Upisite skalar: ";
		cin >> skalar;

		cout << R.to_string() << " * " << skalar << " = ";
		R.Pomnozi(skalar);
		cout << R.to_string() << endl;

		cout << "Zelite li ponovno upisati razlomak (1-da, 0-ne): ";
		cin >> provjera;
	} while (provjera);

	return 0;
}