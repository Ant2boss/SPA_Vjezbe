#pragma once

#include<string>

class Razlomak
{
	int Brojnik;
	int Nazivnik;
public:
	Razlomak();

	void Set_Brojnik(int vrijednost);
	void Set_Nazivnik(int vrijednost);

	void Set_Razlomak(int Brojnik, int Nazivnik);

	void Pomnozi(int skalar);

	std::string to_string();
};

